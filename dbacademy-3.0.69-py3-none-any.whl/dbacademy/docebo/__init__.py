__all__ = ["DoceboRestClient"]

from dbacademy.docebo.docebo_rest_client_class import DoceboRestClient
