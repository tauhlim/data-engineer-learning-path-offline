"""
Modules shared between dbrest and dougrest.  Forms the basis of a shared unified rest client.
"""
