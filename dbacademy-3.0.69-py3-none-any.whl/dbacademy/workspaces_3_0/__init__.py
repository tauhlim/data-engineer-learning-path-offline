"""
This module serves as the basis for the scripts that provision the "Workspace 3.0" set of Databricks Workspaces.
"""
